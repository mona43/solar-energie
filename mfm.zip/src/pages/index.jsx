export {default as Home} from './1-home/home.jsx'; 
export {default as ScrollToTop} from './3-scrollToTop/ScrollToTop.jsx';
export {default as Solar} from './4-solar/solar.jsx';
export {default as Energie} from './5-energie/energie.jsx';
export {default as Contact} from './6-contact/contact.jsx';
export {default as Services} from './7-fima/Services.jsx';


